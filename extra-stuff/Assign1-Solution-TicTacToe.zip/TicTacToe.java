import java.io.Reader;
import java.util.Scanner;

// TBD - Question - Will we have covered statics by Assignment 1?? 
//  Or leave it as an improvement in Assignment 4?
/**
 * @author Schramm
 */
public class TicTacToe {
    
    private int nRows, nColumns;    // Dimensions of grid
    private int numToWin;           // Number of adjacent checkers to be a winner (Must be less than dimensions)
    private char grid[][];           // EMPTY, X or O
    private char turn;               // X or O
    private TicTacToeEnum gameState;  
    private int nMarks;             // Number of plays made.  Used to detect full grid (i.e. a draw)
    
    public TicTacToe(char initialTurn) {
        this(3,3, 3, initialTurn);
    }
    public TicTacToe(int nRows, int nColumns, int numToWin, char initialTurn) {
        if (nRows < 0 || nColumns < 0) 
            throw new IllegalArgumentException("Grid must be a positive size");
        if (numToWin > nRows || numToWin > nColumns) 
            throw new IllegalArgumentException("sizeToWin must be less than dimensions");
        this.nRows = nRows;
        this.nColumns = nColumns;
        this.numToWin = numToWin;
        this.grid = new char[nRows][nColumns];
        reset(initialTurn);
    }
    
    public void reset(char initialTurn) {
        for (int r=0;r<nRows; r++) {
            for (int c=0; c<nColumns; c++) {
                this.grid[r][c] = ' ';
            }
        }
        this.turn = initialTurn;        
        this.nMarks = 0;
        this.gameState = TicTacToeEnum.IN_PROGRESS;
    }
    
    /**
     * @param    row      Where checker is to be added
     * @param    column   Where checker is to be added
     * @return   gateState = {IN_PROGRESS, RED, BLACK, DRAW} 
     * @throws   IllegalArgumentException is the <row,column> is out of range,
     *           or if the location is not adjacent to a filled lower spot
     */
    public TicTacToeEnum takeTurn(int row, int column)  {
        if (this.gameState != TicTacToeEnum.IN_PROGRESS) 
            throw new IllegalArgumentException("Game Over. No more plays");

        if (row < 0 || row > this.nRows) 
            throw new IllegalArgumentException("Grid is " + this.nRows + " by " + this.nColumns);
        if (column < 0 || column > this.nColumns) 
            throw new IllegalArgumentException("Grid is " + this.nRows + " by " + this.nColumns);        
        if (this.grid[row][column] != ' ') 
            throw new IllegalArgumentException("Location is already full");
        this.grid[row][column] = this.turn;
        this.nMarks++;
    
        int oldTurn = this.turn;
        this.turn = (this.turn == 'X') ? 'O' : 'X';
        
        //this.gameState = findWinner(row, column);  // For ConnectFour
        this.gameState = findWinner();
        return this.gameState;
        
    }
 
    private TicTacToeEnum findWinner() {
        TicTacToeEnum newGameState;
        for (int r=0; r<nRows; r++) {
            for (int c=0; c<nColumns; c++) {
                if (grid[r][c] != ' ') {
                    newGameState = findWinnerFrom(r,c);
                    if ( newGameState != TicTacToeEnum.IN_PROGRESS) 
                        return newGameState;
                }
            }
        }
        if (nMarks == this.nRows * this.nColumns) {
            return TicTacToeEnum.DRAW;
        }  
        return TicTacToeEnum.IN_PROGRESS;
    }
    
    private TicTacToeEnum charToEnum (char player) {
        if (player == 'X') return TicTacToeEnum.X_WON;
        if (player == 'O') return TicTacToeEnum.O_WON;
        throw new IllegalArgumentException("charToEnum("+player+"): player must be either X or O");
    }
    /** An internal (private) method that looks for the winner, starting
     *  from a given location.  A winner is a horizontal or vertical row
     *  starting from the given location. Diagonals are not implemented.
     *  Interested students are encouraged to complete it.
     * 
     * Hence the method being made private. The method is used for readability.
     * @param    row      Where to start search
     * @param    column   Where to start search
     * @return   IN_PROGRESS, X_WON, 0_WON, DRAW 
     */
    private TicTacToeEnum findWinnerFrom(int row, int column) {
       
        // Look horizontally - left than right
        
        int count;
        
        count = 1;
        for (int c = column-1; c > 0; c--) {
            if (this.grid[row][column] == this.grid[row][c]) {
                count++;
                if (count == this.numToWin) {
                    return charToEnum(grid[row][column]);
                }
            } // else, look in another direction
        }
        
        count = 1;
        for (int c = column+1; c < this.nColumns; c++) {
            if (this.grid[row][column] == this.grid[row][c]) {
                count++;
                if (count == this.numToWin) {
                    return charToEnum(grid[row][column]);
                }
            } // else, look in another direction
        }
    
        // Look vertically - up then down
        count = 1;
        for (int r = row-1; r > 0; r--) {
            if (this.grid[r][column] == this.grid[row][column]) {
                count++;
                if (count == this.numToWin) {
                     return charToEnum(grid[row][column]);
                }
            } // else, look in another direction
        }
        
        count = 1;
        for (int r = row+1; r < this.nRows; r++) {
            if (this.grid[row][column] == this.grid[r][column]) {
                count++;
                if (count == this.numToWin) {
                    return charToEnum(grid[row][column]);
                }
            } // else, look in another direction
        }        
        
        // Look diagonally - Left-down - TBD
        
        // Look diagonally - Right-down - TBD
      
        return TicTacToeEnum.IN_PROGRESS;
    }
    
    public int getTurn() {
        return this.turn;
    }
    public TicTacToeEnum getGameState() {
        return this.gameState;
    }
    
    public String toString() {
        String s = "";
        for (int r=0;r < nRows; r++ ) {
            for (int c=0; c < nColumns; c++) {
                s += grid[r][c] + " | ";
            }
            s += "\n";
        }
        return s;
    }
    
    public static void main(String args[]) {
        TicTacToe game = new TicTacToe('X');
        Scanner scanner = new Scanner(System.in);

        do { 
            System.out.println(game.toString());
            System.out.println(game.getTurn() + ": Where do you want to mark? Enter row column");
            int row = scanner.nextInt();
            int column = scanner.nextInt();
            scanner.nextLine();
            game.takeTurn(row, column);
            
        } while (game.getGameState() == TicTacToeEnum.IN_PROGRESS);
        System.out.println( game.getGameState());
       
    }
}
