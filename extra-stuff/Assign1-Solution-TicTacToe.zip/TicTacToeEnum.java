/**
 *
 * @author Schramm
 */
public enum TicTacToeEnum {
        IN_PROGRESS, X_WON, O_WON, DRAW;
/*
   IN_PROGRESS ('I'), X_WON ('X'), O_WON ('O'), DRAW ('D');
    
   private char value;
    
   TicTacToeEnum( char value) {
        this.value = value;
    +}
*/
}
