

/** A class */

public class Saving extends BankAccount
{
  private static double interestRate = 2.25;
  private DateClass lastTime;   // Date when interest was last calculated

  public static void setRate(double rate)
  { if (rate > 0) interestRate = rate; }

  public static double getRate()
  { return interestRate; }

  public Saving(String name)
  {
    this( name, 0 );
  }
  public Saving(String name, double deposit)
  {
    super( name );
    this.lastTime = new DateClass();
  }

  public void applyInterest()
  {
    DateClass today = new DateClass();
    DateClass date = this.lastTime;
    date.addDays(30);
    if (date.before(today))
    {
      deposit( getBalance() * interestRate );
      this.lastTime = today;
    }
  }

} 