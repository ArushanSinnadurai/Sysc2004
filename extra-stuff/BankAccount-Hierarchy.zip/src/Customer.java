

public class Customer
{

  public static void main(String[] args)
  {
    BankAccount a1 = new BankAccount("Schramm");
    System.out.println( a1.getHolder() + " has $" + a1.getBalance()
        + " in account " + a1.getNumber() );
        

    Chequing c1 = new Chequing("Schramm");
    BankAccount b = c1;
    System.out.println ("b getCLass " + b.getClass());
    System.out.println ("c1 getCLass " + c1.getClass());
   
    if (b.getClass().toString().equals("class Chequing")) System.out.println ("string true ");
    else System.out.println("string false " + b.getClass().toString());
   if (b.getClass() == c1.getClass()) System.out.println ("true");
    
  }
} 