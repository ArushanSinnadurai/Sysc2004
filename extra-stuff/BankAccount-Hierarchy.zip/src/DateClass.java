import java.util.GregorianCalendar;
import java.text.DateFormat;

public class DateClass
{

  private GregorianCalendar date;

  /** Default construction of "now" */
  public DateClass()
  {
    this.date = new GregorianCalendar();
  }
  /** Constructs the given date  */
  public DateClass(int year, int month, int day)
  {
    this.date = new GregorianCalendar (year, month-1, day, 0, 0, 0 );
  }
  public DateClass(DateClass d)
  {
    this.date = (GregorianCalendar)d.date.clone();
  }

  // Basic mathematical operations on dates
  // Note : Use negative amounts to subtract
  public void addYears(int amount)
  {
    this.date.add(GregorianCalendar.YEAR, amount);
  }
  public void addMonths(int amount)
  {
    this.date.add(GregorianCalendar.MONTH, amount);
  }
  public void addDays(int amount)
  {
    this.date.add(GregorianCalendar.DATE, amount);
  }

  /**
  * Compares the time field records.
  * @param when the Calendar to be compared with this Calendar.
  * @return true if the current time of this Calendar is after/before
  * the time of Calendar when; false otherwise.
  */
  public boolean after(DateClass when)
  {
     return this.date.after( when.date);
  }
  public boolean before(DateClass when)
  {
     return this.date.before( when.date );
  }


  /** Returns the date as a string.<br>
   *  Example: Sep 14, 2005 */
  public String toString() {
    return DateFormat.getDateInstance().format(date.getTime());
  }

  public boolean equals(Object obj)
  {
    if (this == obj) return true;
    if ((obj == null) || !(obj instanceof DateClass) )
        return false;

	  DateClass c = (DateClass)obj;
    return ( this.date.equals( c.date ) );
  }

  public int hashCode( )
  {
    return this.date.toString().hashCode();
  }

 
}

