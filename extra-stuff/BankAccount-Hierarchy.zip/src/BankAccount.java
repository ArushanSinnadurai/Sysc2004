

public class BankAccount
{
  private static int nextAccount = 0;

  private int number;
  private String holder;
  private double balance;

  public BankAccount(String name)
  {
    this( name, 0 );
  }
  public BankAccount(String name, double deposit)
  {
    this.number = nextAccount++;
    this.holder = name;
    if (deposit > 0)
      this.balance = deposit;
    else
      this.balance = 0;
  }

  public int getNumber() { return this.number; }
  public String getHolder() { return this.holder; }
  public double getBalance() { return this.balance; }

  public void deposit(double amount)
  {
    if (amount > 0)
      this.balance += amount;
  }

  public boolean withdraw(double amount)
  {
    if ((amount > 0) && (amount < this.balance))
    {
      this.balance -= amount;
      return true;
    }
    else return false;
  }

}