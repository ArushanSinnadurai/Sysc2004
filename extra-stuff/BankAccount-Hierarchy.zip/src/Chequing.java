
public class Chequing extends BankAccount
{
  private double overdraft;

  public Chequing(String name)
  {
    this( name, 0, 0 );
  }
  public Chequing(String name, double deposit, double overdraft)
  {
     super( name, deposit );
     this.overdraft = overdraft;
  }

  public double getOverdraft() { return this.overdraft; }
  public void setOverdraft(double overdraft)
  {
    if (overdraft >= 0)
      this.overdraft = overdraft;
  }
  
  public boolean withdraw(double amount)
  {
    double current = getBalance();
    if (current >= amount)
        return super.withdraw( amount );
    else // current < amount  ... Overdraft b/c we don't have enough money.
    {
      double deficit = amount - current;  // How much more we need
      if (deficit < this.overdraft)
      {
        // Problem:  We need to get a negative balance!
        // e.g.  super.balance -= amount;
        // but we don't have public access to amount.
        return super.withdraw(amount); // Will throw an exception! Won't let us go negative.
        // Solution: Require protected access (either variable or a method)
        //     super.balance -= amount; 
        // Or perhaps, the superclass is too rigid in its implementation
      }
      else
        return false;
    }
  }
}